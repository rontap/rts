	appver="GAMit\n TAPIS/calkr.js 1.6 ";
	sited="ver.html";
	navname="Load"; //hogy jelenik majd meg
	navplus="Hi";
	coa=false;		
	pack="rontap.mainHelp/loadJS";
	moretag=true;
	manimg='f_icons/props.png';
	document.body.id="body";
	bodys='<rts>'+body.innerHTML;
	body.innerHTML="";
	body.innerHTML+=' <script src="main.js" type="text/javascript"></script>'+bodys.

	
