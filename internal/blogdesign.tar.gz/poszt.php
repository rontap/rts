<?
	$poszt_lekerdezes = sprintf("
		SELECT
			p.id,
			p.cim,
			p.datum,
			p.tartalom,
			p.hsz_lehet,
			f.id,
			f.felhasznaloi_nev,
			f.teljes_nev
		FROM posztok AS p
		JOIN felhasznalok AS f
			ON p.szerzo_id = f.id
	");
?>