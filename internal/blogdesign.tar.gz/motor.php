<?
	session_start() ;
	$ab = new mysqli('localhost','FELHASZNÁLÓNÉV','JELSZÓ','ADATBÁZIS');
	$ab -> set_charset('utf8');
	
	require('login.php');
	
	require('classes/poszt.class.php');
	require('classes/komment.class.php');
	
	// Új blogposzt beszúrása az adatbázisba
	if ( isset($_SESSION['ok']) && $_SESSION['ok'] === 'true' ){
		if (isset($_POST['poszt_cime'], $_POST['poszt_tartalma'])){
			$beszuro_lekerdezes = sprintf("
				INSERT INTO posztok (cim, tartalom, szerzo_id, hsz_lehet)
				VALUES ('%s','%s',%d,%d)",
				$_POST['poszt_cime'] ,
				$_POST['poszt_tartalma'],
				$_SESSION['f_id'],
				( isset( $_POST['hsz_lehet'] ) ? 1 : 0 )	
			) ;
			$ab -> query($beszuro_lekerdezes) ;
		}
	}
	
	// Új komment beszúrása az adatbázisba
	if ( isset($_SESSION['ok']) && $_SESSION['ok'] === 'true' ){
		if (isset($_POST['comment'], $_GET['poszt_id'])){
			$beszuro_lekerdezes = sprintf("
				INSERT INTO hozzaszolasok (tartalom, szerzo_id, poszt_id)
				VALUES ('%s',%d,%d)",
				$_POST['comment'] ,
				$_SESSION['f_id'],
				$_GET['poszt_id']
			) ;
			$ab -> query($beszuro_lekerdezes) ;
		}
	}

?>
