<?
	if ( isset( $_GET['muvelet']) ){
		if ( $_GET['muvelet'] == 'uj_poszt' ){
			require('ujposzt.php');
		} elseif ( $_GET['muvelet'] == 'poszt' && isset( $_GET['poszt_id'] ) ) {
			$poszt = new Poszt( $_GET['poszt_id'], $ab ) ;
		}
	} else { // Ha nincs megadott művelet, az összes cikket megjelenítjük
		$poszt_id_lekerdezes = "
			SELECT id
			FROM posztok
			ORDER BY datum DESC" ;
		$poszt_id_eredmeny = $ab -> query($poszt_id_lekerdezes);
		while ( $aktualis_poszt = $poszt_id_eredmeny -> fetch_assoc()){
			$poszt = new Poszt( $aktualis_poszt['id'], $ab );
		}
	}
?>