<?
	if ( isset($_SESSION['ok']) && $_SESSION['ok'] === 'true' ){
	?>
	<form method="post" style="margin-top:80px;">
		
		<table>
			<tr>
				<td>Cím:</td>
				<td><input type="text" name="poszt_cime"></td>
			</tr>
			<tr>
				<td>Tartalom:</td>
				<td>
					<textarea name="poszt_tartalma"></textarea>
				</td>
			</tr>
			<tr>
				<td></td>
				<td><input type="checkbox" name="hsz_lehet"> Hozzászólások engedélyezése</td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Bejegyzés létrehozása" class="i"></td>
			</tr>
		</table>
	</form>
	<?
	} else {
		?>
        <meta charset="UTF-8">
        <h1 style="margin-top:60px;text-align:center;"><a href="index.php">Új bejegyzés létrehozásához be kell jelentkezned!</a></h1>
		<?
	}
?>