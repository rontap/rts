

<?
	if ( isset($_SESSION['ok']) && $_SESSION['ok'] === 'true' ){
		// Ha be vagyunk jelentkezve
		?>
		<span class="user">Üdv, <?= $_SESSION['f_teljes_nev'] == NULL ? $_SESSION['f_nev'] : $_SESSION['f_teljes_nev'] ?>!</span> 
            <input type="submit" value="Új poszt" onclick="location.search='?muvelet=uj_poszt'" id="newposzt">
		<form method="post" action="<?= $_SERVER['PHP_SELF'] ?>" style="display:inline-block;">
			<input type="hidden" name="kijelentkezes" value="">
			<input type="submit" value="Kijelentkezés">
		</form>
		<?
	} else {
		// Ha nem vagyunk bejelentkezve
		?>
		<form method="post" action="<?= $_SERVER['PHP_SELF'] ?>">
			
					
					<input type="text" name="fnev" spaceholder="Felhasználónév">				
					<input type="password" name="jelszo" spaceholder="Jelszó">				
					<input type="submit" value="Bejelentkezés">
				
		</form>
		<?
	}
?>