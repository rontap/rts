<?php
	require_once('motor.php');
?>
<!DOCTYPE HTML>
<html><head>
	<meta charset="utf-8">
	<title>VPG Blog</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head><body onload="JSL('main.js');">
    
     <img src="profile_icon.png" >
    
	<div id="fejlecKontener">
		<header>
			<h1 onclick="location.href='index.php'">VPG szakkör blog</h1>         
            <img src="up.png" width="40px" class="off">
		</header>
	</div>
	<div id="tartalomKontener">
		<aside id="oldalsav">
			<?php require('loginform.php'); ?>
		</aside>
		<article>
			<?php require('tartalom.php'); ?>
		</article>
		<div class="clearer"></div>
	</div>
	<div id="lablecKontener">
		<footer>
			Copyleft 2014<br><br>
            Készítette: VPG Webfejlesztés szakkör 2013-2014-ben
            <img src="up.png" class="buttup">
		</footer>
	</div>
    <script>
        //gyorsított betöltődés
        JSL("http://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"); 
        function JSL(call) {
        var element = document.createElement("script");
        element.src = call;
        document.body.appendChild(element);
        }
    </script>      
   
</body></html>