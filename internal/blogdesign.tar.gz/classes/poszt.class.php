<?

class Poszt {
	
     
    
	private $ab ;
	private $id ;
	private $cim ;
	private $datum ;
	private $tartalom ;
	private $hozzaszolas_ok ;
	private $szerzo_id ;
	private $szerzo_nev ;
	private $szerzo_teljes_nev ;
	private $hozzaszolasok ;
	
	public function __construct($id, $ab){
		$this -> ab = $ab ;
		$poszt_lekerdezes = sprintf("
			SELECT
				p.id               AS p_id,
				p.cim              AS p_cim,
				p.datum            AS p_datum,
				p.tartalom         AS p_tartalom,
				p.hsz_lehet        AS p_hsz_lehet,
				f.id               AS f_id,
				f.felhasznaloi_nev AS f_nev,
				f.teljes_nev       AS f_teljes_nev
			FROM posztok AS p
			JOIN felhasznalok AS f
				ON p.szerzo_id = f.id
			WHERE p.id = %d",
			$id);
		$poszt_eredmeny = $this -> ab -> query( $poszt_lekerdezes ) ;
		if ( $poszt_eredmeny -> num_rows == 0 ){
			$this -> nemTalalhato();
		} else {
			$aktualis_poszt = $poszt_eredmeny -> fetch_assoc();
			$this -> id = $aktualis_poszt['p_id'];
			$this -> cim = $aktualis_poszt['p_cim'];
			$this -> datum = $aktualis_poszt['p_datum'];
			$this -> tartalom = $aktualis_poszt['p_tartalom'];
			$this -> hozzaszolas_ok = $aktualis_poszt['p_hsz_lehet'];
			$this -> szerzo_id = $aktualis_poszt['f_id'];
			$this -> szerzo_nev = $aktualis_poszt['f_nev'];
			$this -> szerzo_teljes_nev = $aktualis_poszt['f_teljes_nev'];
			$this -> hozzaszolasok = array();
			
			$kommentek_lekerdezes = sprintf("
				SELECT id
				FROM hozzaszolasok
				WHERE poszt_id = %d
				ORDER BY datum DESC",
				$this -> id );
			$kommentek_eredmeny = $ab -> query($kommentek_lekerdezes);
			while ( $komment = $kommentek_eredmeny -> fetch_assoc()){
				$this->hozzaszolasok[] = new Komment( $komment['id'], $this-> ab );
			}
			$this -> megjelenit();
		}
	}
	
	public function megjelenit(){
        
        
		$sablon = file_get_contents('classes/poszt.tpl');
		$mit = array(
			'%id%',
			'%cim%',
			'%szerzo%',
			'%datum%',
			'%tartalom%'
			);
		$mire = array(
			$this -> id,
			$this -> cim,
			( $this -> szerzo_teljes_nev == '')
				? $this->szerzo_nev
				: $this->szerzo_teljes_nev,
			$this -> datum,
			$this -> tartalom
			);
		$sablon = str_replace( $mit, $mire, $sablon );
		echo $sablon ;

        
        
		
		if ( $this -> hozzaszolas_ok == 1 ){
            
            ?> <img src="comment.png" class="commentimg">
                <h2>Hozzászólások</h2> 
            <?
            
            if ( isset($_SESSION['ok']) && $_SESSION['ok'] === 'true' ){
                $sablon = file_get_contents('classes/comment_form.tpl');
                $mit = '%poszt_id%' ;
                $mire = $this -> id ;
                $sablon = str_replace( $mit, $mire, $sablon );
                echo $sablon ;
		      }
            
			foreach ( $this -> hozzaszolasok AS $hsz ){
				$hsz -> megjelenit() ;
			}
		}
        else {
            
            ?> 
                <span class="off">
                <img src="commentoff.png" class="commentimg">
                <h2>Hozzászólások letiltva</h2> 
                </span>
            <?
            
        }

	}
	
	public function nemTalalhato(){
		echo "HIBA: 404, a keresett bejegyzés nem található.<br>" ;
	}
	
}

?>